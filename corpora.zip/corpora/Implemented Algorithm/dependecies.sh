sudo apt-get install python3-pip
sudo pip3 install -r requirements.txt
